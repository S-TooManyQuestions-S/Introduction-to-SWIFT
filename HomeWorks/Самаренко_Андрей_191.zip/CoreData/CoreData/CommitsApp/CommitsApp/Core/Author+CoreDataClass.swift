//
//  Author+CoreDataClass.swift
//  CommitsApp
//
//  Created by Андрей Самаренко on 30.11.2020.
//
//

import Foundation
import CoreData

@objc(Author)
public class Author: NSManagedObject {

}
