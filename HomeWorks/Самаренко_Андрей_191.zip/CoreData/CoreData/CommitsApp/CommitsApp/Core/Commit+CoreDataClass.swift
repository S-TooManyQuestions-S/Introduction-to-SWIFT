//класс для описания логики взаимодействия с данными

import Foundation
import CoreData

@objc(Commit)
public class Commit: NSManagedObject {
}
